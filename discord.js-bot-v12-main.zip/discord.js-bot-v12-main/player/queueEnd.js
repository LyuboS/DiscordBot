module.exports = (client, message, queue) => {
    message.channel.send(`📍 - Music stopped as there is no more music in the queue !`);
};